package com.service;

import java.util.HashMap;
import java.util.List;

import com.dao.StudentDAO;
import com.dto.StudentDTO;

public interface StudentService {

	public void setDao(StudentDAO dao);
	 // 전체 학생 목록
	public List<StudentDTO> selectAllStudent();
	// 학생명 검색 목록
	public List<StudentDTO> selectByName(String searchName);
	//입학년도 범위 검색
	public List<StudentDTO> selectByEntranceDate(HashMap<String, String> map);
	
}

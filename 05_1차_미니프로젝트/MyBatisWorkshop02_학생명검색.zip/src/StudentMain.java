import java.util.List;
import java.util.Scanner;

import com.dao.StudentDAO;
import com.dto.StudentDTO;
import com.service.StudentService;
import com.service.StudentServiceImpl;

public class StudentMain {
	
	static StudentService service = new StudentServiceImpl();

	public static void main(String[] args) {

		service.setDao(new StudentDAO());
		
		Scanner scan = new Scanner(System.in);
		
		while(true) {
			printMainMenu();
			
			String inputMenu = scan.next();
			
			switch (inputMenu) {
				case "0": exit();break;
				case "1": printSelectAllStudent();break;
				case "2": { 
					System.out.print("검색할 학생명을 입력하시오 =>");
					String searchName = scan.next();
					printSelectByName(searchName);
				}break;

			}//end switch
		}//end while
	}//end main
	
	// 학생명 검색 목록
	private static void printSelectByName(String searchName) {
		List<StudentDTO> list = service.selectByName(searchName);
		System.out.println("================================");
		System.out.println("학번\t이름\t주민번호\t\t\t주소\t\t\t입학년도\t\t휴학여부");
		System.out.println("================================");
	    for (StudentDTO dto : list) {
			System.out.printf("%s\t%s\t%s\t\t%s\t\t%s\t\t%s \n", dto.getStuNo(),
					         dto.getStuName(), dto.getStuSsn(), dto.getStuAddress(),
					         dto.getEntDate(), dto.getAbsYn());
		}
		System.out.printf("총 학생수: %d 명 \n", list.size() );
	}
	
	 // 전체 학생 목록
	private static void printSelectAllStudent() {
		
		List<StudentDTO> list = service.selectAllStudent();
		System.out.println("================================");
		System.out.println("학번\t이름\t주민번호\t\t\t주소\t\t\t입학년도\t\t휴학여부");
		System.out.println("================================");
	    for (StudentDTO dto : list) {
			System.out.printf("%s\t%s\t%s\t\t%s\t\t%s\t\t%s \n", dto.getStuNo(),
					         dto.getStuName(), dto.getStuSsn(), dto.getStuAddress(),
					         dto.getEntDate(), dto.getAbsYn());
		}
		System.out.printf("총 학생수: %d 명 \n", list.size() );
	}//end printSelectAllStudent
	
	
     // 프로그램 종료하는 메서드
	private static void exit() {
		System.out.println("프로그램이 종료되었습니다.");
		System.exit(0);
	}
		
	// 메뉴 출력 하는 메서드
	private static void printMainMenu() {
		System.out.println("*******************************");
		System.out.println("\t [학생 정보 관리 메뉴]");
		System.out.println("*******************************");
		System.out.println("1. 전체 학생 목록");
		System.out.println("2. 학생 이름 검색");
		System.out.println("0. 종료");
		System.out.println("*******************************");
		System.out.print("메뉴 입력 =>");
	}
	
	
	
}//end class

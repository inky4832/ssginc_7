package com.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.StudentDTO;

// MySQL DB 연동하는 전담 클래스
public class StudentDAO {

	public List<StudentDTO> selectAllStudent(SqlSession session){
		List<StudentDTO> list = session.selectList("com.config.StudentMapper.selectAllStudent");
		return list;
	}
	public List<StudentDTO> selectByName(SqlSession session,String searchName){
		List<StudentDTO> list = session.selectList("com.config.StudentMapper.selectByName", searchName);
		return list;		
	}
	public List<StudentDTO> selectByEntranceDate(SqlSession session,
			                                         HashMap<String, String> map) {
		List<StudentDTO> list = 
				session.selectList("com.config.StudentMapper.selectByEntranceDate", map);
		return list;		
		
	}
	public List<StudentDTO> selectBySearchNo(SqlSession session,
			List<String> no_list) {
		List<StudentDTO> list = 
				session.selectList("com.config.StudentMapper.selectBySearchNo", no_list);
		return list;
	}
	
	public int updateAbsenceChange(SqlSession session,
			List<String> no_list) {
		int n = session.update("com.config.StudentMapper.updateAbsenceChange", no_list);
		return n;
	}
}

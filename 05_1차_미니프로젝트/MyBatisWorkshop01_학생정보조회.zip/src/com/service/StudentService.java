package com.service;

import java.util.List;

import com.dao.StudentDAO;
import com.dto.StudentDTO;

public interface StudentService {

	public void setDao(StudentDAO dao);
	 // 전체 학생 목록
	public List<StudentDTO> selectAllStudent();
}

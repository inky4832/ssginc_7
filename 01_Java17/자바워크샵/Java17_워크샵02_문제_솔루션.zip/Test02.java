
public class Test02 {
	public static void main(String[] args) {

		int num = 456;
		int result = num / 100 * 100;
		System.out.println(result);
	}
}
package pack98;

public class Otab extends Mobile {

	
	public Otab() {
		super();
	}

	public Otab(String mobileName, int batterySize, String osType) {
		super(mobileName, batterySize, osType);
	}

	@Override
	public int operate(int time) {
//		사용을 통해 배터리 감소 구현,  
//		1분 사용 시 밧데리 12감소 
//		잔여 배터리 리턴
		// 배터리 = 현재배터리 - (time*10)
		int battery = getBatterySize() - (time*12);
		setBatterySize(battery);
		return getBatterySize() ;
	}

	@Override
	public int charge(int time) {
//		충전을 통한 배터리 증가 구현 
//		1분 충전 시 밧데리 10증가 
//		잔여 배터리 리턴
		int battery = getBatterySize() + (time*8);
		setBatterySize(battery);
		return getBatterySize() ;
	}

}

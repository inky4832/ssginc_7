package pack98;

public class MobileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 각각의 Mobile 객체를 생성한다. 
		Ltab ltab = new Ltab("Ltab", 500, "AP-01");
		Otab otab = new Otab("Otab", 1000, "AND-20");
		
        // 생성된 객체의 정보를 출력한다. 
		System.out.println("Mobile \t Battery \t OS");
		System.out.println("-------------------------");
		System.out.println(ltab.getMobileName()+"\t"+ltab.getBatterySize()+"\t"+ltab.getOsType());
		System.out.println(otab.getMobileName()+"\t"+otab.getBatterySize()+"\t"+otab.getOsType());
		
        // 각각의 Mobile 객체에 10분씩 충전을 한다.  
		// 10분 충전 후 객체 정보를 출력한다. 
		System.out.println("10분 충전");
		ltab.charge(10);
		otab.charge(10);
		System.out.println("Mobile \t Battery \t OS");
		System.out.println("-------------------------");
		System.out.println(ltab.getMobileName()+"\t"+ltab.getBatterySize()+"\t"+ltab.getOsType());
		System.out.println(otab.getMobileName()+"\t"+otab.getBatterySize()+"\t"+otab.getOsType());
		
        // 각각의 Mobile 객체에 5분씩 통화를 한다. 
        // 5분 통화 후 객체 정보를 출력한다. 
		System.out.println("5분 통화");
		ltab.operate(5);
		otab.operate(5);
		System.out.println("Mobile \t Battery \t OS");
		System.out.println("-------------------------");
		System.out.println(ltab.getMobileName()+"\t"+ltab.getBatterySize()+"\t"+ltab.getOsType());
		System.out.println(otab.getMobileName()+"\t"+otab.getBatterySize()+"\t"+otab.getOsType());
	}

}



public class MyTest02 {

	public static void main(String[] args) {

		 long ssn = 8310202182637L;
		 System.out.println("나의 주민번호:" + ssn);
		

	}

}

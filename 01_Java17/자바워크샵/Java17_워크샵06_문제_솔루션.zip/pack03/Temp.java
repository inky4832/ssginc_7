package pack03;

public interface Temp {
	public int getTempGage();
}

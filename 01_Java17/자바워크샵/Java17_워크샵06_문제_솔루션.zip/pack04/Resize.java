package pack04;
public interface Resize {
	public void setResize(int size);
}

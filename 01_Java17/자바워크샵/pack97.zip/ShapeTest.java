package pack97;

public class ShapeTest {

	public static void main(String[] args) {
		
		//다형성 배열
		Shape shape[] = new Shape[6]; 
		shape[0] = new Triangle(7, 5, "Blue");
		shape[1] = new Rectangle(4, 5, "Blue");
		shape[2] = new Triangle(6, 7, "Red");
		shape[3] = new Rectangle(8, 3, "Red");
		shape[4] = new Triangle(9, 8, "White");
		shape[5] = new Rectangle(5, 7, "White");

		for (Shape s : shape) {
			if( s instanceof Triangle) {
			  System.out.println("Triangle \t "+ s.getArea() +"\t" + s.getColors());
			}else {
				System.out.println("Rectangle \t "+ s.getArea() +"\t" + s.getColors());				
			}
		}
		
		// 크기변경5
		for (Shape s : shape) {
			Resize x = (Resize)s;  // up-casting
			x.setResize(5);
		}
		
		System.out.println("#####################");
		for (Shape s : shape) {
			if( s instanceof Triangle) {
			  System.out.println("Triangle \t "+ s.getArea() +"\t" + s.getColors());
			}else {
				System.out.println("Rectangle \t "+ s.getArea() +"\t" + s.getColors());				
			}
		}
	}

}

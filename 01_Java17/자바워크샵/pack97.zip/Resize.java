package pack97;

public interface Resize {

	public abstract void setResize(int size);  // 사이즈 변경 
}

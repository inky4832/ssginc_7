package pack97;

public class Triangle extends Shape implements Resize {

	public Triangle() {
		super();
	}

	public Triangle(int width, int height, String colors) {
		super(width, height, colors);
	}

	@Override
	public void setResize(int size) {
         // 도형의 사이즈 변경
		//Triangle에서의 setResize() 함수는 세로(height)의 값에 size 값을 더한다 
		//int resize = getHeight() + size;
		setHeight(getHeight() + size);
	}
	@Override
	public double getArea() {
		// 도형의 넓이를 리턴 
		// 넓이 = 가로 * 세로 / 2
		return (getWidth() * getHeight()) / 2.0;
	}

}

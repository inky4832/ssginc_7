package pack97;

public class Rectangle extends Shape implements Resize {

	
	public Rectangle() {
		super();
	}
	public Rectangle(int width, int height, String colors) {
		super(width, height, colors);
	}
	@Override
	public void setResize(int size) {
		 // 도형의 사이즈 변경
		//Rectangle에서의 setResize() 함수는 가로(width)의 값에 size 값을 더한다
	    setWidth(getWidth()+size);
	}
	@Override
	public double getArea() {
		// 도형의 넓이를 리턴 
		// 넓이 = 가로 * 세로
		return (double)getWidth() * getHeight();
	}

}

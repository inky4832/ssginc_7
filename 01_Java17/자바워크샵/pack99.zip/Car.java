package pack99;

public class Car extends Vehicle {
	
	 private double restOil; // 현재 탱크에 남은 오일 
	 private int curWeight;  // 현재 중량 ( 최대 중량을 넘어설 수 없다. )
	
	 public Car() {
		super();
	}
	public Car(int maxWeight, double oilTankSize, double efficiency) {
		super(maxWeight, oilTankSize, efficiency);
	}
	public void addOil(int oil) {
//		현재 오일량에 추가한다. 
//		단, 오일탱크크기를 넘어서면 안된다. 
		if( (restOil + oil) <= getOilTankSize()) {
		  restOil += oil;
		}
	} 
	public void moving(int distance) {
    //연비와 주행거리에 따라 오일량을 감소 시킨다. 
		restOil -= ( distance / getEfficiency());
	} 
	public void addWeight(int weight) {
//		현재 적재량에 물건을 추가한다. 
//		단, 최대적재중량을 넘어서면 안된다. 
		if( (curWeight + weight) <= getMaxWeight()) { 
		    curWeight += weight;
		}
	}
	
	public double getRestOil() {
		return restOil;
	}
	public void setRestOil(double restOil) {
		this.restOil = restOil;
	}
	public int getCurWeight() {
		return curWeight;
	}
	public void setCurWeight(int curWeight) {
		this.curWeight = curWeight;
	}
	@Override
	public String toString() {
		return super.toString() + "\t"  +restOil +"\t" + curWeight;
	} 
	 
    	
}



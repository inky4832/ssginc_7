package pack99;

public class VehicleTest {

	public static void main(String[] args) {

		Truck car = new Truck(1000, 100, 5);  // 생성순서: Object > Vechicle > Car > Truck
        // 초기 트럭의 정보를 출력한다. 
		System.out.println("최대적재중량 \t 오일탱크크기 \t 잔여오일량 \t 현재적재중량 \t 연비");
		System.out.println("==========================================================");
		System.out.println(car); // car.toString()
        
		// 50L 주유 후 트럭의 정보를 출력한다. 
		System.out.println("50L 주유 후");
		car.addOil(50);
		System.out.println(car); // car.toString()
		
        // 50Km 주행 후 트럭의 정보를 출력한다.
		System.out.println("50Km 주행 후");
		car.moving(50);
		System.out.println(car); // car.toString()
		
		// 100Kg을 적재한 후 트럭의 정보를 출력한다. 
		System.out.println("100Kg을 적재한 후");
		car.addWeight(100);
		System.out.println(car); // car.toString()
		
		// 30Km 주행 후 트럭의 정보를 출력한다.
		System.out.println("30Km 주행 후 ");
		car.moving(30);
		System.out.println(car); // car.toString()
		
		// 요금 출력
		System.out.println("요금: " + car.getCost(30) +"원");
		
	}
}
